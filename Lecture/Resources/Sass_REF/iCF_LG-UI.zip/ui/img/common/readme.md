* put images here that are used by common styles
* use folders for images that are going to be sprited.