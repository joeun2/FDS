* put images here that are used specifically by the global css. it should be mostly empty, maybe a logo.
* use folders for images that are going to be sprited.