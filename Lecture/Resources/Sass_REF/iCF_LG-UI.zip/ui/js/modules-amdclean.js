var require = {
    'modules': [{
        'name': 'global/global.main'
    }, {
        'name': 'products/products.main',
        'exclude': ['global', 'jquery', 'lodash']
    }]
};
