/**
 * Hero Carousel module.
 * @module hero/hero-carousel
 */
define(['jquery', 'slick-carousel'], function($, slick) {

    'use strict';

    var carousel = {};

    $('.hero-carousel').slick({
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 300,
        dots: true,
        arrows: false,
        pauseOnHover: true,
        pauseOnDotsHover: true
    });

    console.log('hero-carousel');

    return carousel;
});
