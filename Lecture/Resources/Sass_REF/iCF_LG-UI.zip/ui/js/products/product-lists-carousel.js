/* global define */

/**
 * Product List Carousel module.
 * @module products/prodcuts-lists-carousel
 * @requires ic/ic
 * @requires ic/ui/module
 */


define(['global-config', 'jquery', 'slick-carousel'], function(globalConfig, $, slick) {

    'use strict';

    var productCarousel = {};

    $('.product-lists.with-carousel').each(function(idx, item) {
        var carouselLocation;
        var carouselId = "product-list-carousel" + idx;
        this.id = carouselId;

        carouselLocation = "#" + carouselId + ' .carousel';
        var numberOfSlidesToShow = 3;

        if (typeof $(this).attr('data-slides-to-show') !== "undefined") {
            numberOfSlidesToShow = $(this).attr('data-slides-to-show');
        }

        if (globalConfig.isMobile === true) {
            $(carouselLocation).slick({
                slidesToShow: numberOfSlidesToShow,
                slidesToScroll: 1,
                dots: false,
                arrows: true,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: true,
                        arrows: false,
                    }
                }]
            });

        } else {
            $(carouselLocation).slick({
                slidesToShow: numberOfSlidesToShow,
                slidesToScroll: 1,
                dots: false,
                arrows: true
            });
        }
    });

    return productCarousel;
});
