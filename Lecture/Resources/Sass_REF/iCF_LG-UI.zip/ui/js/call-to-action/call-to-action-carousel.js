/* global define */

/**
 * CAll To Action Carousel module.
 * @module call-to-action-carousel
 */
define(['jquery', 'slick-carousel'], function($, slick) {

    'use strict';

    var ctaCarousel = {};

    $('.call-to-action-carousel').slick({
        //speed: 300,
        dots: true


    });

    console.log('call-to-action-carousel');

    return ctaCarousel;
});
