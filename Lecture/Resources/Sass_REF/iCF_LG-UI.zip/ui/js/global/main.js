/**
 * The global main module.
 * @module global/global
 */
define(['jquery',
        'common/app-header',
        'common/app-header-mobile',
        'common/app-meganav',
        'common/app-mylg',
        'hero/hero-carousel',
        'call-to-action/call-to-action-carousel',
        'products/product-lists-carousel',
        'products/product-lists-view-more',
        'common/app-tabs',
        'common/read-more'
    ],

    function($, appHeader, appHeaderMobile, appMegaNav, AppMyLG, heroCarousel, ctaCarousel, productCarousel, productViewMore, appTabs, readMore) {

        'use strict';

        console.log('hello global');

        // var $ = ic.$;

        $('button').click(function() {
            console.log("This button was clicked");
        });

        // what I'm returning here is "global" when you require this module
        //return {};
    });
