require(['global']);
