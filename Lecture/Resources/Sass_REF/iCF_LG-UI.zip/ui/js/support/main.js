/**
 * The products main module.
 * @module products/products
 */
define([], function() {

    'use strict';

    console.log('support js');

    alert('Hello There! \n\nFrom,\nsupport.js');

    // what I'm returning here is "global" when you require this module
    return {};
});
