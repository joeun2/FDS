/**
 * The app header module.
 * @module common/app-header
 * @requires ic/ic
 * @requires ic/ui/module
 */
define(['ic/ic', 'ic/ui/module', 'lodash'], function(ic, Module, _) {

    'use strict';

    var proto,
        events = ic.events,
        dom = ic.dom,
        $window = dom.$window,
        isIE8 = dom.$html.hasClass('lt-ie9'),
        isTabletNav = false;

    var AppMeganav = function(el, options) {
        var self = this;
        // Call the parent constructor
        AppMeganav.superclass.constructor.call(self, el, options);

        self.$meganavMenus = $(self.$('> nav'));
        self.$tabletNav = $(self.$('.tablet-sub-nav'));
        self.$tabletNavLinks = self.$tabletNav.find('a');
        self.currentTabletNavIndex = 0;
        self._init();
        self._resize();
    };

    // Inherit from Module
    ic.util.inherits(AppMeganav, Module);

    // Alias the prototype for less typing and better minification
    proto = AppMeganav.prototype;

    proto._defaults = {
        ac: 'active'
    };

    proto._init = function() {
        var self = this,
            eventHandler = $.proxy(self._handleEvent, self);

        self.$el.on('mouseenter', $.proxy(self._meganavOverHandler, self));
        self.$el.on('mouseleave', $.proxy(self._meganavMouseOut, self));

        events.subscribe('app.meganav.open', $.proxy(self._meganavOpenHandler, self));
        events.subscribe('app.meganav.close', $.proxy(self._meganavCloseHandler, self));

        self.$tabletNavLinks.on('click', function(e) {
            var index = parseInt($(e.target).data('index'));
            self.currentTabletNavIndex = index;
            $(self.$meganavMenus).addClass('hide');
            $(self.$meganavMenus.get(index)).removeClass('hide').addClass(self.options.ac);

            $(self.$tabletNav.find('li')).removeClass(self.options.ac);
            $(self.$tabletNav.find('li').get(index)).addClass(self.options.ac);
        });

        var debouncedResize = ic.util.debounce(function(e) {
            self._handleEvent(e);
        }, 50);

        var debouncedScroll = ic.util.debounce(function(e) {
            self._handleEvent(e);
        }, 10);

        $window.on('scroll', (isIE8) ? eventHandler : debouncedScroll);
        $window.on('resize', (isIE8) ? eventHandler : debouncedResize);
    }

    proto._handleEvent = function(e) {
        var self = this;
        if (e.type == 'resize') self._resize(e);
        e.preventDefault();
    };

    proto._resize = function(e) {
        var self = this,
            sections,
            maxHeight = 1;

        isTabletNav = ($window.width() <= 1024 ? true : false);
        self.$meganavMenus.each(function(index) {
            $(this).addClass('active').removeClass('hide');
            sections = $(this).find("section");
            sections.each(function(index) {
                $(this).css('height', '');
                maxHeight = ($(this).height() > maxHeight ? $(this).height() : maxHeight);
            });
            sections.height(maxHeight);
            maxHeight = 1;
            $(this).removeClass('active').addClass('hide');
        });
    };

    proto._meganavOpenHandler = function(data) {
        var self = this;
        if (data.index == 0 && isTabletNav) {
            //todo factor next four lines into separate function
            $(self.$tabletNav.find('li')).removeClass(self.options.ac);
            $(self.$tabletNav.find('li').get(self.currentTabletNavIndex)).addClass(self.options.ac);

            $(self.$meganavMenus).addClass('hide');
            $(self.$meganavMenus.get(self.currentTabletNavIndex)).addClass(self.options.ac).removeClass('hide');

            self.$tabletNav.removeClass('hide');

        } else {
            self.$tabletNav.addClass('hide');
            $(self.$meganavMenus).removeClass(this.options.ac).addClass('hide');
            $(self.$meganavMenus.get(data.index)).addClass(this.options.ac).removeClass('hide');
        }
        self.$el.addClass(this.options.ac);
    };

    proto._meganavCloseHandler = function(data) {
        var self = this;
        self.$el.removeClass(this.options.ac);
    }
    proto._meganavOverHandler = function(e) {
        var self = this;
        self.$el.addClass(this.options.ac);
        events.publish('app.meganav.on', [$(e.currentTarget).data('index')]);
    }

    proto._meganavMouseOut = function(e) {
        var self = this;
        self.$el.removeClass(this.options.ac);
        events.publish('app.meganav.off', [$(e.currentTarget).data('index')]);
    };

    // Create the jquery plugin and set it to auto-wire to specified selector
    ic.jquery.plugin('appMeganav', AppMeganav, '.app-meganav');

    return AppMeganav;
});
