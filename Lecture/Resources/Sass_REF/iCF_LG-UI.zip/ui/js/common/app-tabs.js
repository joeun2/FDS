/* global define */

/**
 * A module representing a Dog.
 * @module common/dog
 * @requires  common/util
 * @requires  common/animal
 */
define(['ic/ic', 'ic/ui/module', 'common/util', 'common/debounce'], function(ic, Module, util, debounce) {

    'use strict';

    var util = ic.util,
        plugin = ic.jquery.plugin,
        events = ic.events,
        $document = $(document),
        $window = $(window),
        $appHeader = $('.appHeader'),
        $wrapper = $('.wrapper'),
        oldIE = false,
        proto;

    if ($('html').is('.lt-ie9')) {
        $document = $window;
        oldIE = true;
    }

    var AccordionTabs = function(el, options) {
        console.log('AccordionTabs', el, options);
        var self = this;

        // extend Tabs
        // Tabs.call(self, el, options);

        // Call the parent constructor
        AccordionTabs.superclass.constructor.call(self, el, options);

        // selectors
        self.$wrapper = $(el);
        //self.$panelWrapper = self.$wrapper.find('.tabs-panels'); // this is gone now. just need to calc height for all elements that would have been in here.
        self.$tabPanels = self.$wrapper.find('.tabs-panel');
        self.$tabAnchors = self.$('a.tab-anchor'); // = self.$('.accordion-tab'); // this anchor wrapper div is being removed.
        self.$tabsNav = self.$('.tabs-nav');
        self.$tabs = self.$tabsNav.find('li');
        /**
         * Holds the index of the active item.
         * @type {Number}
         * @default  0
         */
        self._active = 0;
        self._scrollFlag = true;

        // Event Handlers
        self.$el.on(events.CLICK_EVENT, '[data-toggle="tab"]', $.proxy(self._onTabClick, self));
        self.$el.on(events.CLICK_EVENT, 'a.tab-anchor', $.proxy(self._onAnchorClick, self));
        window.addEventListener('resize', debounce($.proxy(self._setAnchorPositions, self), 250, false));
        // if ($wrapper.length > 0) {
        // $document.scroll(self._scrollHandler);
        $document.scroll(debounce($.proxy(self._onScroll, self), 10, false));
        // }

        // additional initialization
        self._initActiveItem();

        // create anchor positions
        setTimeout($.proxy(self._setAnchorPositions, self), 100);

        // initialize positioning of tabs
        self._fixTabsNav();
        if (oldIE) {
            setInterval($.proxy(self._fixTabsNav, self), 120);
        }
    };

    // util.inherits(AccordionTabs, Tabs);
    util.inherits(AccordionTabs, Module);
    proto = AccordionTabs.prototype;

    // overwrite default tabs event handler
    proto._onTabClick = function(e) {
        var self = this;
        var href = $(e.target).attr('href') ? $(e.target).attr('href') : $(e.target).find('a').attr('href');
        var $anchor = $(href)[0];

        e.preventDefault();

        console.log('_onTabClick', href, $anchor);

        // if (typeof(href) !== 'undefined' && href.substr(0, 1) === '#') { // if anchor
        // if ($href.length > 0) { // if anchor exists on page
        //     var position = $href.offset().top - $appHeader.height() - self.$tabsNav.height();

        //     // prevent scroll updates while animating
        //     self._scrollFlag = false;

        //     $('html, body').animate({
        //         scrollTop: position + 1
        //     }, 'fast', function() {
        //         // add back scroll updates
        //         self._scrollFlag = true;
        //     });
        // }
        // }

        self._goToAnchor($anchor);

        self._clickHandler(e);
    };

    proto._onAnchorClick = function(e) {
        var self = this;
        var id = $(e.target).attr('id');
        var $anchor = $('#' + id);

        // if (self.$tabAnchors[idx].hasClass('active')) {
        //     //remove active class.
        //     return;
        // }
        self._goToAnchor($anchor);

        self._clickHandler(e);
    };

    proto._clickHandler = function(e) {
        var self = this,
            idx = self.$tabs.index($(e.currentTarget).parent()[0]);

        if (idx === -1) {
            idx = self.$tabAnchors.index($(e.currentTarget));
        }

        // console.log('click handler:', idx, e.currentTarget);
        self.setActive(idx);

        e.preventDefault();
    };

    proto._goToAnchor = function($anchor) {
        var position;

        if ($anchor.length > 0) {
            return;
        }

        position = $anchor.offset().top - $appHeader.height() - self.$tabsNav.height();
        // prevent scroll updates while animating
        self._scrollFlag = false;

        $('html, body').animate({
            scrollTop: position + 1
        }, 'fast', function() {
            // add back scroll updates
            self._scrollFlag = true;
        });
    };

    /**
     * Set the active tab, anchor, and panel.
     * @memberof! module:ic/ui/app-tabs#
     * @param {int} idx The index of the tab you want active.
     * @return {AccordionTabs} `this` object instance.
     */
    proto.setActive = function(idx) {
        var self = this;

        // if the item clicked is already active then do nothing
        if (self._active === idx) {
            console.log('setActive', 'this tab is already active. no change.', self._active, idx);
            return self;
        }

        // this will return `self`
        console.log('setActive', 'this tab is not active. change.', self._active, idx);
        return self._change(idx);
    };

    /**
     * Change the active tab, anchor, and panel.
     * @memberof! module:ic/ui/app-tabs#
     * @private
     * @param  {int} idx The index of the item to set active.
     * @return {AccordionTabs} `this` object instance.
     */
    proto._change = function(idx) {
        var self = this,
            activeClass = 'active',
            $tab,
            $anchor,
            $tabPanel;

        self.beforeChange();

        // get reference to the tab and panel we want to make active
        $tab = $(self.$tabs[idx]);
        $anchor = $(self.$tabAnchors[idx]);
        $tabPanel = $(self.$tabPanels[idx]);

        // make current active tab and panel not active
        self.$tabs.removeClass(activeClass);
        self.$tabAnchors.removeClass(activeClass);
        self.$tabPanels.removeClass(activeClass);

        // make new tab and panel active
        $tab.addClass(activeClass);
        $anchor.addClass(activeClass);
        $tabPanel.addClass(activeClass);

        // update the active tab index
        // console.log('change', idx, self.$tabs[idx], $tab, $tab[0]);
        self._active = $tab[0]; //self._active = $anchor[0];

        self.afterChange();

        return self;
    };



    // fixes the position of the desktop tabs when scrolling within the tab group.
    proto._fixTabsNav = function() {
        var self = this;
        return debounce(function(e) {
            var scrollTop = $document.scrollTop() + $appHeader.height();
            var tabsBottom = self.$wrapper.offset().top + $appHeader.height() + self._getPanelsHeight() - self.$tabsNav.height();

            self.$tabsNav.toggleClass('fixed-top', self.$wrapper.offset().top < scrollTop && tabsBottom > scrollTop);

            if (self.$tabsNav.hasClass('fixed-top')) {
                self.$tabsNav.css({
                    'min-height': self.$tabsNav.height() + 'px',
                    'top': $appHeader.height() + 'px'
                });
            }
        }, 25)();
    };

    // When the user scrolls, check if the new position should cause a state change.
    proto._onScroll = function() {
        var self = this;
        var activeTab = false;

        if (!self._scrollFlag) {
            return;
        }

        self.$tabPanels.each(function(n, e) {
            var $this = $(this);
            var scrollTop = $document.scrollTop() + $appHeader.height() + self.$tabsNav.height(); // + ($window.height() / 2);
            var panelTop = $this.offset().top;
            // console.log('panel top offset', scrollTop, panelTop, self.$tabsNav.height());
            var target = $this.attr('data-id');
            var tab = self.$tabsNav.find('a[href="#' + target + '"]').parent();
            // console.log('panel active?', tab.length, scrollTop > panelTop);
            if (tab.length > 0 && scrollTop > panelTop) {
                activeTab = tab;
            }
        });

        self.$tabs.removeClass('active');
        if (activeTab !== false) {
            activeTab.addClass('active');
        }
        self._fixTabsNav();
    };

    // Determines position of the tab panels. Used to trigger onScroll.
    proto._setAnchorPositions = function() {
        var self = this;
        var $anchors = self.$tabAnchors;
        var h = $appHeader.height();

        $anchors.css('top', '-' + h + 'px');
    };

    proto._getPanelsHeight = function() {
        var self = this;
        var h = 0; // height;

        // loop through all anchors and panels, adding their heights.
        self.$tabAnchors.each(function() {
            h += $(this).outerHeight(true);
        });
        self.$tabPanels.each(function() {
            h += $(this).outerHeight(true);
        })

        return h;
    };

























    /**
     * Initializes the cached active index. If no items are active sets the
     * first item active.
     * @memberof! module:ic/ui/tabs#
     * @private
     * @return {void}
     */
    proto._initActiveItem = function() {
        var self = this,
            $active = self.$tabs.find('.active');

        // if no items active then set the first item active
        if ($active.length === 0) {
            self.setActive(0);

            // set active to 0 because it's the first index
            self._active = 0;
        }

        self._active = $active[0]; // set the index of the active item
    };



    /**
     * Gets called before a tab changes to active.
     * @memberof! module:ic/ui/tabs#
     * @return {void}
     */
    proto.beforeChange = function() {
        var self = this;

        self.emit('beforechange', self._active);
    };

    /**
     * Gets called after a tab has changed to active.
     * @memberof! module:ic/ui/tabs#
     * @return {void}
     */
    proto.afterChange = function() {
        var self = this;

        self.emit('afterchange', self._active);
    };

    /**
     * Returns the active index. If no items are active sets the first item active.
     * @memberof! module:ic/ui/tabs#
     * @return {int} The index of the active item.
     */
    proto.getActiveIndex = function() {
        var self = this,
            $active = self.$tabs.find('.active');

        // if no items active then set the first item active
        if ($active.length === 0) {
            self.setActive(0);

            // return 0 because it's the first index
            return 0;
        }

        return $active[0]; // return the index of the active item
    };









    plugin('appTabs', AccordionTabs, '.app-tabs');

    return AccordionTabs;
});
