/**
 * The app header module.
 * @module common/app-header
 * @requires ic/ic
 * @requires ic/ui/module
 */
define(['ic/ic', 'ic/ui/module'], function(ic, Module) {

    'use strict';

    var proto,
        events = ic.events,
        $window = ic.dom.$window;

    var AppHeader = function(el, options) {
        var self = this;

        // Call the parent constructor
        AppHeader.superclass.constructor.call(self, el, options);

        //Desktop Nav Items
        self.$primaryNavLinks = $('#appHeader .primary-nav-link').data('open', false);
        self.$searchTakeover = self.$('.search-takeover');
        self.$primaryNavSearch = self.$('.primary-nav-search');
        self.$searchInput = self.$searchTakeover.find('input');
        self.$searchCloseBtn = self.$('.right-side-nav').find('.primary-nav-search-close').hide();
        self.currentNavIndex = 0;

        self._init();
    };

    // Inherit from Module
    ic.util.inherits(AppHeader, Module);

    // Alias the prototype for less typing and better minification
    proto = AppHeader.prototype;

    proto._defaults = {
        //active class
        ac: 'active'
    };

    proto._init = function() {
        var self = this,
            eventHandler = $.proxy(self._handleEvent, self);

        //Desktop Nav Listeners
        self.$primaryNavLinks.on('mouseover', $.proxy(self._primaryNavOverHandler, self));
        self.$primaryNavLinks.on('mouseout', $.proxy(self._primaryNavOutHandler, self));
        self.$primaryNavSearch.on('click', $.proxy(self._positionSearch, self));
        self.$searchCloseBtn.on('click', $.proxy(self._closeSearch, self));

        events.subscribe('app.meganav.off', $.proxy(self._deativatePrimaryNavItem, self));
        events.subscribe('app.meganav.on', $.proxy(self._activatePrimaryNavItem, self));
    }

    proto._handleEvent = function(e) {
        var self = this;
        e.preventDefault();
    };

    proto._positionSearch = function(e) {
        var self = this,
            searchBoxWidth = self.$searchInput.outerWidth();
        $('.primary-nav-biz, .primary-nav').css({
            'opacity': 0,
            'pointer-events': 'none'
        });
        $('.primary-nav-biz').hide().next().show().find('.icon').removeClass('hide');
        // console.log("padding " + parseInt(self.$primaryNavSearch.css('padding-right')));

        self.$searchTakeover.css('left', self.$primaryNavSearch.offset().left - self.$searchTakeover.outerWidth() + parseInt(self.$primaryNavSearch.css('padding-right')) / 2 + 5).addClass(this.options.ac);
    }

    proto._closeSearch = function(e) {
        var self = this;
        $('.primary-nav-biz, .primary-nav').css({
            'opacity': 1,
            'pointer-events': 'auto'
        });
        $('.primary-nav-biz').show().next().hide();
        self.$searchTakeover.removeClass(this.options.ac);
        e.preventDefault();
    };

    proto._primaryNavOverHandler = function(e) {
        //console.log("primary nav over handler ");
        var $currentTarget = $(e.currentTarget),
            index = $(e.currentTarget).data('index'),
            eventType,
            self = this;

        self.currentNavIndex = index;
        //If the mega menu isn't open
        if ($currentTarget.data('open') === false) {
            //Only allow one menu open at a time
            self.$primaryNavLinks.removeClass(this.options.ac);
            //Set main nav link to active with open data
            $currentTarget.data('open', true).addClass(this.options.ac);
            //Tell meganav module to open something
            events.publish('app.meganav.open', [{
                index: index
            }]);
        }
    };

    proto._primaryNavOutHandler = function(e) {
        var $currentTarget = $(e.currentTarget),
            index = $(e.currentTarget).data('index');

        events.publish('app.meganav.close', [{
            index: $(e.currentTarget).data('index')
        }]);
        $currentTarget.data('open', false).removeClass(this.options.ac);
    };

    proto._deativatePrimaryNavItem = function(index) {
        var self = this;
        $(self.$primaryNavLinks.get(self.currentNavIndex)).data('open', false).removeClass(this.options.ac);
    };

    proto._activatePrimaryNavItem = function(index) {
        var self = this;
        $(self.$primaryNavLinks.get(self.currentNavIndex)).data('open', true).addClass(this.options.ac);
    };


    var _updateScroll = function() {
        //todo
    };

    var _onCollapse = function() {
        //todo
    };

    //   Create the jquery plugin and set it to auto-wire to specified selector
    ic.jquery.plugin('appHeader', AppHeader, '.appHeader');

    return AppHeader;
});
